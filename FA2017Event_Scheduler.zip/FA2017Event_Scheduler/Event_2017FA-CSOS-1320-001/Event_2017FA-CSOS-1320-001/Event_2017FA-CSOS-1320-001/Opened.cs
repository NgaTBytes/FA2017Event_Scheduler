﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Event_2017FA_CSOS_1320_001
{
    public class Opened : Event
    {
        public virtual void DetailedOverview()
        {
            // Method that was created in the parent event class 
            // to show to the participants the event details when they see and 
            // open event.
        }
    }
}