﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Event_2017FA_CSOS_1320_001
{
    public class Participant : User
    {
        public virtual void Register()
        {
            // Code to enbale Participants to regester whther its a closed event
            // they will have the opportunity to call this to register. This method is already 
            // defined in the parent class User.

        }
    }
}